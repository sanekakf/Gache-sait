# Основа для сайта, серверная часть
from flask import Flask, render_template, request, flash, redirect
import psycopg2 as ps
import psycopg2.extras


app = Flask(__name__)
app.config['SECRET_KEY'] = 'aboba'


DB_HOST = 'ec2-54-170-163-224.eu-west-1.compute.amazonaws.com'
DB_NAME = 'df043ppajn3au9'
DB_USER = 'lfcjpjxpmcfqxi'
DB_PASS = '70ec9d90f402e4102fb1ea1d8699a2a0c232034016d6edacd6d681093a20772b'
conn = ps.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST)
cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)


@app.route('/')
def index():
    return render_template('main.html')


@app.route('/pricing')
def pricing():
    return render_template('pricing.html')


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        if request.method == 'POST':
            cur.execute('SELECT * FROM users')
            print(cur.fetchall())
            name = request.form.get('login')
            password = request.form.get('password')
            try:
                cur.execute('SELECT admin FROM users WHERE login = %s', (name,))
                law = cur.fetchone()
                law = law[0]
                if law:
                    cur.execute('SELECT password FROM users WHERE login = %s', (name,))
                    _pass = cur.fetchall()
                    print(_pass)
                    if _pass[0][0] == password:
                        cur.execute('SELECT login FROM users WHERE login = %s', (name,))
                        user = cur.fetchone()
                        user = user[0]
                        print(user)
                        flash('Вход был выполнен успешно', category='success')
                        return redirect('/admin-page')
                    else:
                        flash('Пароль или логин не совпадает', category='error')
                else:
                    flash('У вас нет права для перехода на страницу администрации', category='error')
            except Exception as e:
                print(e)
                flash('Такого аккаунта не существует, создайте его по ссылке ниже', category='error')
    return render_template('admin.html')


@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        name = request.form.get('login')
        password = request.form.get('password')
        cur.execute('INSERT INTO users VALUES (%s,%s,%s)', (str(name), str(password), False))
        conn.commit()
        cur.execute('SELECT * FROM users')
        print(cur.fetchall())
        flash('Аккаунт успешно создан', category='success')
        return redirect('/login')
    return render_template('register.html')


@app.route('/update')
def update():
    return render_template('update_log.html')


@app.route('/buy', methods=['POST', 'GET'])
def buy():
    if request.method == 'POST':
        login = request.form.get('login')
        cur.execute('SELECT login FROM users WHERE login = %s', (login,))
        user = cur.fetchone()
        print(user)
        if user is None:
            flash('Такого пользователя не существует', category='error')
        else:
            cur.execute('UPDATE users SET admin = %s WHERE login = %s', (True, login,))
            conn.commit()
            flash('Админка была выдана удачно', category='success')
            redirect('/admin-page')

    return render_template('buy.html')


@app.route('/admin-page', methods=['POST', 'GET'])
def admin():
    return render_template('admin-page.html')


# обработка ошибочных страниц
@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404


@app.errorhandler(500)
def server_error(error):
    return render_template('505.html'), 500


if __name__ == '__main__':
    cur.execute("SELECT * FROM users")
    print(cur.fetchall())
    # cur.execute('CREATE TABLE IF NOT EXISTS users (login TEXT PRIMARY KEY, password TEXT)')
    app.run(debug=True)
